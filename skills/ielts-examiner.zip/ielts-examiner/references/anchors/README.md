# Anchors — how to use and grow this set

Anchor essays are the single most important calibration tool in this skill. They turn abstract band descriptors into concrete reference points: "is this essay closer to the band-6 anchor or the band-7 anchor, and why?" Comparison against real examples is the strongest defense against the model's tendency to inflate scores.

## What's here
- `task2-band6.0.md` — original annotated essay, scored 6.0
- `task2-band7.0.md` — original annotated essay, scored 7.0 (same prompt, for direct contrast)

These two are starter anchors written for this skill (original, not from copyrighted test books).

## How to grow it (the data flywheel)
The best anchors are **your own students' essays with a teacher-verified band.** Every time a teacher overrides an AI score in the admin console, you have a labeled example. Promote the clear, instructive ones into this folder.

Target coverage:
- One or two anchors per **half-band from 5.0 to 8.0** (5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0).
- Across **task types** (opinion, discussion, problem-solution, two-part).
- Each with the same annotation structure: per-criterion band + evidence (citing error-taxonomy IDs) + score-blocker + band-with-fixes.

## Format rules for a good anchor
1. Real or realistic essay text, exactly as a candidate at that band would write it (don't "clean it up").
2. Per-criterion justification that points to **specific evidence**, not feelings.
3. Use the error-taxonomy IDs so anchors and live grading speak the same language.
4. State *why it isn't the band above* — the boundary is what the model needs to learn.

## Privacy
If an anchor comes from a real student, get consent, strip names and identifying details, and don't include anything that could identify a minor. Anchors are reference text the grader reads — treat them as you would any stored personal data.
